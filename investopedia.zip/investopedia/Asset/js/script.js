// Toggle Dark/Light Mode
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
  }
// Toggle Dark/Light Mode
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
  }
  
  // Toggle Hamburger Menu
  function toggleMenu() {
    const navLinks = document.getElementById('navLinks');
    navLinks.classList.toggle('show');
  }



//   read more

function toggleReadMore(span) {
    const card = span.closest('.card');
    const fullText = card.querySelector('.full-content');
    const isVisible = fullText.style.display === 'block';
  
    fullText.style.display = isVisible ? 'none' : 'block';
    span.textContent = isVisible ? 'Read More' : 'Read Less';
  }
  


  
    
 